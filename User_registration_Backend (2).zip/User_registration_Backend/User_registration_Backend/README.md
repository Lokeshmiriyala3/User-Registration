# Django User Registration System

## Project Overview

This project is a backend implementation of a user registration system using Django. The system includes features like email confirmation, user profile management, and password reset.

## Setup Instructions

1. Clone the repository:
   ```sh
   git clone <repository_url>
   cd user_registration
   ```
